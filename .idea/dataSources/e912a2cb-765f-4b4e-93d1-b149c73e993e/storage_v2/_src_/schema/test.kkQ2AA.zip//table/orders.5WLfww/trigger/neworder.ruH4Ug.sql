create trigger neworder
  after INSERT
  on orders
  for each row
  select new.order_num into @ed;

