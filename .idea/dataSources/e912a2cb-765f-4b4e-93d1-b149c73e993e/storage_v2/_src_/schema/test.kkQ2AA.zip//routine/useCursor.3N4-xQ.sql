create procedure useCursor()
BEGIN
declare tmpName varchar(20) default '' ;  
declare allName varchar(255) default '' ;  
declare cur1 CURSOR FOR SELECT name FROM test.level ;
declare CONTINUE HANDLER FOR SQLSTATE '02000' SET tmpname = null; 
OPEN cur1;
FETCH cur1 INTO tmpName;
WHILE ( tmpname is not null) DO 
set tmpName = CONCAT(tmpName ,";") ; 
set allName = CONCAT(allName ,tmpName) ; 
FETCH cur1 INTO tmpName;
END WHILE;
select allName ;
END;

