create procedure productpricing(OUT pl decimal(8, 2), OUT ph decimal(8, 2), OUT pa decimal(8, 2))
BEGIN 
SELECT MIN(prod_price)
INTO pl
FROM products ;
SELECT MAX(prod_price)
INTO ph
FROM products ;
SELECT AVG(prod_price)
INTO pa
FROM products ;
END;

